var msg = function() {
	window.alert('' + txt)
}

var msg2 = function() {
	window.alert('' + txt2)
}

var msg3 = function() {
	window.alert('' + txt3)
}

var msg4 = function() {
	window.alert('' + txt4)
}

var msg5 = function() {
	window.alert('' + txt5)
}

var msg6 = function() {
	window.alert('' + txt6)
}

var msg7 = function() {
	window.alert('' + txt7)
}

var msg8 = function() {
	window.alert('' + txt8)
}

var msg9 = function() {
	window.alert('' + txt9)
}

var msg10 = function() {
	window.alert('' + txt10)
}

var txt, txt2, txt3, txt4, txt5, txt6, txt7, txt8, txt9, txt10;