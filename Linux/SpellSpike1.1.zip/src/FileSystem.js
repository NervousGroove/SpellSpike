var OpenFileExplorer = function() {
	window.location.href = "C:\"
}