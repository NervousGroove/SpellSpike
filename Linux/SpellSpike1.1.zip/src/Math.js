var mathsum = function() {
document.write(a + b);
}

var mathsubtract = function() {
document.write(a - b);
}

var mathsplit = function() {
document.write(a / b);
}

var mathmultiply = function() {
document.write(a * b);
}

var mathsum2 = function() {
document.write(a2 + b2);
}

var mathsubtract2 = function() {
document.write(a2 - b2);
}

var mathspli2t = function() {
document.write(a2 / b2);
}

var mathmultiply2 = function() {
document.write(a2 * b2);
}

var mathsum3 = function() {
document.write(a3 + b3);
}

var mathsubtract3 = function() {
document.write(a3 - b3);
}

var mathsplit3 = function() {
document.write(a3 / b3);
}

var mathmultiply3 = function() {
document.write(a3 * b3);
}

var mathsum4 = function() {
document.write(a4 + b4);
}

var mathsubtract4 = function() {
document.write(a4 - b4);
}

var mathsplit4 = function() {
document.write(a4 / b4);
}

var mathmultiply4 = function() {
document.write(a4 * b4);
}

var a, b, a1, b2, a2, b3, a3, b3, a4, b4;