var audio, audio2, audio3, audio4, audio5, audio6, audio7, audio8, audio9, audio10, audio11, audio12, audio13, audio14, audio15, audio16, audio17, audio18, audio19, audio20

var playaudio = function() {
	audio.play();
}

var playaudio2 = function() {
audio2.play();
}

var playaudio3 = function() {
audio3.play();
}

var playaudio4 = function() {
audio4.play();
}

var playaudio5 = function() {
audio5.play();
}

var playaudio6 = function() {
audio6.play();
}

var playaudio7 = function() {
audio7.play();
}

var playaudio8 = function() {
audio8.play();
}

var playaudio9 = function() {
audio9.play();
}

var playaudio = function() {
audio10.play();
}
var playaudio10 = function() {
audio11.play();
}

var playaudio11 = function() {
audio12.play();
}

var playaudio12 = function() {
audio13.play();
}

var playaudio13 = function() {
audio14.play();
}

var playaudio14 = function() {
audio15.play();
}

var playaudio15 = function() {
audio16.play();
}

var playaudio17 = function() {
audio17.play();
}

var playaudio18 = function() {
audio18.play();
}

var playaudio19 = function() {
audio19.play();
}

var playaudio20 = function() {
audio20.play();
}