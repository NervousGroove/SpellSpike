var p, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22, p23, p24, p25, p26, p27, p28, p29, p30, p31, p32, p33, p34, p35;

var print = function() {
	document.write("" + p)
}

var print2 = function() {
	document.write('' + p2)
}

var print3 = function() {
	document.write('' + p3)
}

var print4 = function() {
	document.write('' + p4)
}

var print5 = function() {
	document.write('' + p5)
}

var print6 = function() {
	document.write('' + p6)
}

var print7 = function() {
	document.write('' + p7)
}

var print8 = function() {
	document.write('' + p8)
}

var print9 = function() {
	document.write('' + p9)
}

var print10 = function() {
	document.write('' + p10)
}

var print11 = function() {
	document.write('' + p11)
}

var print12 = function() {
	document.write('' + p12)
}

var print13 = function() {
	document.write('' + p13)
}

var print14 = function() {
	document.write('' + p14)
}

var print15 = function() {
	document.write('' + p15)
}

var print16 = function() {
	document.write('' + p16)
}

var print17 = function() {
	document.write('' + p17)
}

var print18 = function() {
	document.write('' + p18)
}

var print19 = function() {
	document.write('' + p19)
}

var print20 = function() {
	document.write('' + p20)
}

var print21 = function() {
	document.write('' + p21)
}

var print22 = function() {
	document.write('' + p22)
}

var print23 = function() {
	document.write('' + p23)
}

var print24 = function() {
	document.write('' + p24)
}

var print25 = function() {
	document.write('' + p25)
}

var print26 = function() {
	document.write('' + p26)
}

var print27 = function() {
	document.write('' + p27)
}

var print28 = function() {
	document.write('' + p28)
}

var print29 = function() {
	document.write('' + p29)
}

var print30 = function() {
	document.write('' + p30)
}

var print31 = function() {
	document.write('' + p31)
}

var print32 = function() {
	document.write('' + p32)
}

var print33 = function() {
	document.write('' + p33)
}

var print34 = function() {
	document.write('' + p34)
}

var print35 = function() {
	document.write('' + p35)
}


