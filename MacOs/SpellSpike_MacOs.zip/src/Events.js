//OnClick Event
var OnClick = function() {
	getElementById('' + Element)
}

var OnClick2 = function() {
	getElementById('' + Element2)
}

var OnClick3 = function() {
	getElementById('' + Element3)
}

var OnClick4 = function() {
	getElementById('' + Element4)
}

var OnClick5 = function() {
	getElementById('' + Element5)
}

var OnClick6 = function() {
	getElementById('' + Element6)
}

var OnClick7 = function() {
	getElementById('' + Element7)
}

var OnClick8 = function() {
	getElementById('' + Element8)
}

var OnClick9 = function() {
	getElementById('' + Element9)
}

var OnClick10 = function() {
	getElementById('' + Element10)
}

var Element, Element2, Element3, Element4, Element5, Element6, Element7, Element8, Element9, Element10;

var OnLoad = function() {
	document.onload = OnLoadAction()
}

var OnLoadAction, OnLoadAction2;

