//WebGL
var WebGL = function() {
	console.log('This game/software is rendering with WebGL')
}
//OpenGL
var OpenGL = function() {
	console.log('This game/software is rendering with OpenGL')
}
//GLES3
var GLES3 = function() {
	console.log('This game/software is rendering with GLES3')
}
//GLES2
var GLES2 = function() {
	console.log('This game/software is rendering with GLES3')
}

var renderer, renderer2