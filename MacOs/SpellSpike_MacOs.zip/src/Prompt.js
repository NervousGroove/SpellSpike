var Prompt = function() {
	let person = prompt("" + PromptInfo, "" + PromptInput);
}

var Prompt2 = function() {
	let person = prompt("" + PromptInfo, "" + PromptInput);
}

var Prompt3 = function() {
	let person = prompt("" + PromptInfo, "" + PromptInput);
}

var Prompt4 = function() {
	let person = prompt("" + PromptInfo, "" + PromptInput);
}

var Prompt5 = function() {
	let person = prompt("" + PromptInfo, "" + PromptInput);
}

var Prompt6 = function() {
	let person = prompt("" + PromptInfo, "" + PromptInput);
}

var Prompt7 = function() {
	let person = prompt("" + PromptInfo, "" + PromptInput);
}

var Prompt8 = function() {
	let person = prompt("" + PromptInfo, "" + PromptInput);
}

var Prompt9 = function() {
	let person = prompt("" + PromptInfo, "" + PromptInput);
}

var Prompt10 = function() {
	let person = prompt("" + PromptInfo, "" + PromptInput);
}

var PromptInfo, PromptInfo2, PromptInfo3, PromptInfo4, PromptInfo5, PromptInfo6, PromptInfo7, PromptInfo8, PromptInfo9, PromptInfo10

var PromptInput, PromptInput2, PromptInput3, PromptInput4, PromptInput5, PromptInput6, PromptInput7, PromptInput8, PromptInput9, PromptInput10